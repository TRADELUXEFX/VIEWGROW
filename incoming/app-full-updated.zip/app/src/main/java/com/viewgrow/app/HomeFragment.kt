package com.viewgrow.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import org.json.JSONObject

// Home: countdown, the contacts number, and whatever the database says is happening now.
// The database decides the state (web_status). This screen only shows it.
class HomeFragment : Fragment(R.layout.fragment_home) {

    private val ui = Handler(Looper.getMainLooper())
    private var status: JSONObject? = Status.last
    private var syncing = false
    private var generation = 0
    private var lastLoad = 0L
    private var lastAuto = 0L
    private var syncError: String? = null
    private var savingSpinner: Spinner? = null

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        Ui.bindUserHeader(view)
        Fonts.apply(view)
        // The admin's contact (for the WhatsApp buttons) comes from the website's settings.
        Remote.load { if (isAdded && view.parent != null) render() }
        if (status != null) render() else showLoading()
    }

    // ---- Loading ring ----

    private var bar: android.animation.ObjectAnimator? = null

    // Until the database has answered, only a loading bar slides across the top. Nothing else, so no wrong state flashes.
    private fun showLoading() {
        val v = view ?: return
        v.findViewById<View>(R.id.home_scroll).visibility = View.INVISIBLE
        val track = v.findViewById<View>(R.id.home_loading)
        val fill = v.findViewById<View>(R.id.home_loading_fill)
        track.visibility = View.VISIBLE
        if (bar?.isRunning == true) return
        track.post {
            if (track.visibility != View.VISIBLE || track.width == 0) return@post
            bar?.cancel()
            bar = android.animation.ObjectAnimator.ofFloat(fill, View.TRANSLATION_X, -fill.width.toFloat(), track.width.toFloat()).apply {
                duration = 1000
                repeatCount = android.animation.ValueAnimator.INFINITE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                start()
            }
        }
    }

    private fun hideLoading() {
        val v = view ?: return
        bar?.cancel()
        bar = null
        v.findViewById<View>(R.id.home_loading).visibility = View.GONE
        v.findViewById<View>(R.id.home_scroll).visibility = View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        tick()
        ui.postDelayed(ticker, 1000)
        reload()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        bar?.cancel()
        bar = null
        savingSpinner?.stop()
        savingSpinner = null
        ui.removeCallbacksAndMessages(null)
    }

    // ---- Countdown ----

    private fun tick() {
        val v = view ?: return
        v.findViewById<TextView>(R.id.timer).text = Release.format(Release.secondsLeft())
        // The release time has passed: ask the database again.
        if (Release.expired() && System.currentTimeMillis() - lastLoad > 15000) reload()
    }

    // ---- Loading ----

    private fun reload() {
        if (!Store.loggedIn) return
        if (status == null) showLoading()
        lastLoad = System.currentTimeMillis()
        val mine = ++generation
        var pending = 2
        var result: ApiResult? = null
        fun finish() {
            pending--
            if (pending > 0) return
            val r = result ?: return
            if (mine != generation || !isAdded || view == null) return
            handle(r)
        }
        Release.load { finish() }
        val args = JSONObject().put("p_phone", Store.phone).put("p_pin", Store.password)
        Api.call("web_status", args) { r ->
            result = r
            finish()
        }
    }

    private fun handle(r: ApiResult) {
        val v = view ?: return
        val j = r.json
        if (j == null) {
            if (status == null) showProblem(Api.netMessage(r.error)) else Ui.toast(v, Api.netMessage(r.error))
            return
        }
        if (!j.optBoolean("ok")) {
            val code = j.optString("code")
            // Banned and Blocked get their own full screens.
            if (AccountGate.handle(activity as? MainActivity, j)) return
            if (code == "WRONG_PIN" || code == "NOT_FOUND" || code == "INVALID_PHONE") {
                Ui.toast(v, Api.loginMessage(j))
                (activity as? MainActivity)?.onLoggedOut()
            } else if (status == null) {
                showProblem("Could not check. Please try again.")
            }
            return
        }
        status = j
        Status.last = j
        val name = j.optString("name")
        if (name.isNotEmpty() && name != Store.name) {
            Store.name = name
            Ui.bindUserHeader(v)
        }
        render()
        maybeAutoSync()
    }

    private fun showProblem(message: String) {
        val v = view ?: return
        hideLoading()
        val ctx = v.context
        val body = v.findViewById<LinearLayout>(R.id.body)
        body.removeAllViews()
        body.addView(HomeViews.notice(ctx, HomeViews.WARN, "Could not load.", message))
        val retry = HomeViews.button(ctx, body, "Try again", null)
        retry.setOnClickListener { reload() }
        body.addView(retry)
        Fonts.apply(body)
    }

    // ---- Drawing the state ----

    private fun render() {
        val v = view ?: return
        val j = status ?: return
        hideLoading()
        val ctx = v.context
        val body = v.findViewById<LinearLayout>(R.id.body)
        body.removeAllViews()
        savingSpinner?.stop()
        savingSpinner = null
        val top = v.findViewById<LinearLayout>(R.id.top_slot)
        top.removeAllViews()

        val state = j.optString("state")
        val verified = state != "NOT_VERIFIED"
        // Not verified: no countdown. The "Not verified yet" box takes its place at the top.
        v.findViewById<View>(R.id.countdown).visibility = if (verified) View.VISIBLE else View.GONE
        setBadge(v, verified)
        // The contacts card leads. Under the "Not verified yet" box it needs a gap; at the top it does not.
        v.findViewById<View>(R.id.stat_card).let {
            (it.layoutParams as LinearLayout.LayoutParams).topMargin = if (verified) 0 else Ui.dp(ctx, 12)
            it.requestLayout()
        }

        val total = if (j.isNull("total")) 0 else j.optInt("total")
        val limit = if (j.isNull("limit")) "\u2014" else j.optInt("limit").toString()
        setStats(v, total, limit, state == "LIMIT_REACHED")

        // The automatic sync looks dead on a phone brand that blocks background apps.
        if (OemAutostart.needsPrompt()) {
            body.addView(HomeViews.autostartCard(ctx) { activity?.let { OemAutostart.openSettings(it) } })
        }

        val name = Store.name
        val recentSync = Store.lastSyncAt > 0L && Store.lastSyncCount > 0 &&
            System.currentTimeMillis() - Store.lastSyncAt < 24L * 3600L * 1000L

        when (state) {
            "NOT_VERIFIED" -> {
                val warn = HomeViews.notice(ctx, HomeViews.WARN, "Not verified yet.", "Reshare the admin\u2019s status to unlock your contacts.")
                (warn.layoutParams as LinearLayout.LayoutParams).topMargin = 0
                top.addView(warn)
                Fonts.apply(top)
                body.addView(HomeViews.stepsCard(ctx))
                val msg = "Hi, I just registered on ViewGrow. My name is $name."
                if (Remote.adminLink(msg) != null) {
                    val b = HomeViews.button(ctx, body, "Message admin on WhatsApp", null)
                    b.setOnClickListener { openAdmin(msg) }
                    body.addView(b)
                }
            }
            "READY" -> {
                // Contacts save by themselves when Home opens. This only shows the progress, or why it failed.
                val err = syncError
                if (syncing) {
                    val sp = Spinner(ctx, ContextCompat.getColor(ctx, R.color.green_text), 16, 2)
                    savingSpinner = sp
                    body.addView(HomeViews.savingRow(ctx, sp))
                    sp.start()
                } else if (err != null) {
                    body.addView(HomeViews.notice(ctx, HomeViews.WARN, "Couldn\u2019t save contacts.", err))
                }
            }
            "LIMIT_REACHED" -> {
                body.addView(HomeViews.limitCard(ctx))
                val msg = "Hi, I have reached my contact limit on ViewGrow. My name is $name. I would like to pay to upgrade my limit so I can receive new contacts."
                if (Remote.adminLink(msg) != null) {
                    val b = HomeViews.button(ctx, body, "UPGRADE CONTACT LIMIT", null)
                    b.setOnClickListener { openAdmin(msg) }
                    body.addView(b)
                }
            }
            "PREPARING" -> {
                // Verified, waiting for the release. The countdown already says when, so nothing else shows.
            }
            "ALREADY_TODAY", "NOTHING_NEW", "NO_POOL" -> {
                if (recentSync) {
                    val n = Store.lastSyncCount
                    body.addView(HomeViews.notice(ctx, HomeViews.GREEN, "Contacts saved.", (if (n == 1) "1 new contact is" else "$n new contacts are") + " now in your phone."))
                    } else if (state == "ALREADY_TODAY") {
                    body.addView(HomeViews.notice(ctx, HomeViews.GREEN, "Already downloaded today.", "You\u2019ve used today\u2019s download. Come back tomorrow, after your reshare is verified."))
                } else if (state == "NOTHING_NEW") {
                    body.addView(HomeViews.notice(ctx, HomeViews.GREEN, "All caught up.", "You\u2019ve received all your contacts for now. New ones arrive after your next verified reshare."))
                } else {
                    body.addView(HomeViews.notice(ctx, HomeViews.GREEN, "No contacts today.", "Nothing new to save. You\u2019re all set."))
                }
            }
            else -> {
                body.addView(HomeViews.notice(ctx, HomeViews.WARN, "Nothing to save right now.", "Check back later."))
            }
        }

        val recent = j.optJSONArray("recent")
        if (state != "NOT_VERIFIED" && recent != null && recent.length() > 0) {
            val days = j.optInt("days", recent.length())
            body.addView(HomeViews.recentCard(ctx, recent, days) { (activity as? MainActivity)?.showTab(1) })
        }
        Fonts.apply(body)
    }

    private fun setBadge(v: View, verified: Boolean) = Ui.setBadge(v, verified)

    // 312/500 with the /500 smaller. The total goes red when the limit is reached.
    private fun setStats(v: View, total: Int, limit: String, atLimit: Boolean) {
        val ctx = v.context
        val text = "$total/$limit"
        val s = SpannableString(text)
        val cut = total.toString().length
        s.setSpan(RelativeSizeSpan(0.55f), cut, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.muted)), cut, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (atLimit) s.setSpan(ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.red_dark)), 0, cut, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        v.findViewById<TextView>(R.id.stat_received).text = s
        val lim = limit.toIntOrNull()
        v.findViewById<GaugeView>(R.id.stat_gauge).set(if (lim != null && lim > 0) total.toFloat() / lim else 0f, atLimit)
    }

    // ---- WhatsApp ----

    private fun openAdmin(text: String) {
        val link = Remote.adminLink(text) ?: return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: ActivityNotFoundException) {
            view?.let { Ui.toast(it, "Could not open the link.") }
        }
    }

    // ---- Saving contacts to the phone ----

    // Home saves the contacts by itself as soon as the database says they are ready.
    // Paused means paused: nothing is saved on open either.
    private fun maybeAutoSync() {
        val ctx = context ?: return
        if (syncing || status?.optString("state") != "READY") return
        if (Store.syncPaused || Store.banned) return
        val now = System.currentTimeMillis()
        if (now - lastAuto < 20000L) return
        if (!ContactsSaver.hasPermission(ctx)) {
            syncError = "Allow Contacts in Profile so ViewGrow can save your contacts."
            render()
            return
        }
        lastAuto = now
        startSync()
    }

    private fun startSync() {
        val ctx = context ?: return
        syncing = true
        syncError = null
        render()
        Sync.start(ctx) { res ->
            syncing = false
            if (!isAdded || view == null) return@start
            if (res.banned) {
                (activity as? MainActivity)?.showBanned()
                return@start
            }
            if (res.ok) {
                syncError = null
                reload()
            } else {
                // Another sync (the timer) already running is not an error worth showing.
                syncError = if (res.message.startsWith("Already syncing")) null else res.message
                render()
            }
        }
    }
}
