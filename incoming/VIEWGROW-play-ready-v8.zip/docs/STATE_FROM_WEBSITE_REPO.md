# ViewGrow: current state (website, database, Android app)

Last updated: 16 Nov 2026. This file is private (the supabase/ folder is blocked by netlify.toml). **Update it with every change.**

## Rules for anyone (human or AI) changing anything
1. **Read this file, `schema.md` and `changelog.md` first.** Search them for the name of anything you are about to create. If it is already there, change it; do not write a second version.
2. **Never assume the database matches these notes.** Before writing any SQL or function, run the read-only check (`check_how_it_works.sql` QUERY 1, or the specific check) and use the live result. The live database is the truth.
3. One change = one migration file in `migrations/`, applied by the owner in the SQL Editor, then recorded in `changelog.md` (status: applied, date, how it was confirmed) and in `schema.md`.
4. A change made in the dashboard with no file must be written down here the same day. Example: `migrations/20261116150000_purchases_record_of_live.sql`.
5. The website is the source of truth for rules (limits, release time, bans). The Android app uses the same database and must say the same thing.
6. When something is replaced, delete the old version from the files and the notes. Do not keep drafts, "suggested" copies or "not yet applied" notes for things that are done or dropped.

## What is live (verified 16 Nov 2026)
| Area | State |
|---|---|
| Member site + admin | As in `readme.md`. Admin tabs: Today, Pool, Users, Settings. |
| Deleted-numbers list | Live. A deleted number cannot log in or sign up (ACCOUNT_DELETED). Admin removes a number from `deleted_numbers` to let it back. |
| In-app Delete my account | Live (`web_delete_account`, file `20261116180000`). Deletes the member's purchase records, saved contacts and account, and puts the number on the list. No approval step. |
| Admin Delete user | Does not add the number to the deleted list. Refuses banned members. Leaves `web_purchases` rows. |
| Release schedule | Installed and set to Daily (10pm Lagos). Nightly job runs every night. Confirmed 16 Nov 2026. |
| Pack purchases | Edge Function `verify-purchase` deployed and tested with a fake token (NOT_FOUND_AT_GOOGLE). `web_purchase_precheck` and `web_apply_purchase` live. A pack ADDS to the limit. A token Google already marked consumed is refused. **A real test purchase has not been done.** |
| Privacy, Terms, Delete My Account pages | Match the app (16 Nov 2026). Deploy the website zip to Netlify if not done yet. |

## Android app (package com.viewgrow.app)
- Built with GitHub Actions (`.github/workflows/deploy.yml`): Java 17, Gradle 8.11.1, AGP 8.10.1, compileSdk and targetSdk 36, Play Billing 8.0.0. Needs secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD for the Play bundle.
- 43 Kotlin files in `app/src/main/java/com/viewgrow/app/`. No `res/xml` folder, no sync adapter, no battery request, no auto-start code (removed for Google Play).
- Talks to Supabase with the public (anon) key through database functions. Purchases go to the Edge Function (`Api.kt` sends `web_verify_purchase` to `/functions/v1/verify-purchase`).
- The app's own notes are its `README.md`. Keep both in step.

## Plain-words guide
`HOW_EVERYTHING_WORKS.md` explains the whole scheme (members, app, website, admin, rules) without technical words. Update it when a feature or rule changes.

## Checking the live site and app
Run `check_live_matches_claims.sql` (read only, 8 queries; run each one in its own tab). All 8 passed on 16 Nov 2026. It tests that every function the app and site call exists, the 10pm clock and nightly job, the release schedule, the deleted-number block, row-level security and leftovers.

## Open items
1. Confirm the Android build is green on GitHub.
2. Deploy the website zip to Netlify.
3. Play Console: create products contacts_1000, contacts_3000, contacts_5000; upload the app file; forms (see the app's `docs/PLAY_STORE_CHECKLIST.md`).
4. Real purchase test with a Play test account (a row should appear in `web_purchases` and the limit should rise by the pack size).
5. Owner decisions: (a) should admin Delete user also add the number to `deleted_numbers`? (b) should admin Delete user also delete `web_purchases` rows? (c) should a member's own delete keep the payment records (for refund disputes and accounting)?
6. Test a deleted number live: delete a test account in the app, then run QUERY 4 in `check_live_matches_claims.sql` (the deleted-number line should say ACCOUNT_DELETED).
