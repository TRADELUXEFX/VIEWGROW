# ViewGrow (Android)

Android version of the ViewGrow website. Native Kotlin, package `com.viewgrow.app`.
It signs up and logs in with the same WhatsApp number and password as the website, and uses the same Supabase database (`Config.kt`). The app never decides who gets which contacts: the database does, with the same rules as the website. Plain-words guide to everything (app, website, database): `docs/HOW_EVERYTHING_WORKS.md`. The live state of the whole project is in `docs/STATE_FROM_WEBSITE_REPO.md` (a copy of the website repo's `supabase/STATE.md`).

## Build
- GitHub Actions (`.github/workflows/deploy.yml`) builds the APK and the Play bundle on every push to `main`: Java 17, Gradle 8.11.1, AGP 8.10.1, compileSdk and targetSdk 36.
- `versionCode` is `1 + the run number`, so each build installs over the last. Profile shows the app version.
- The Play bundle needs the upload key (secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD). Without them the build makes a test APK only.

## What the app does
- **Welcome, Sign up, Log in.** Light and dark mode. Sign-in screens shrink while the keyboard is open. Text size follows the phone's Font size up to 2.0x.
- **Home.** Contacts used and limit (gauge), countdown to the next release, and every state (not verified, limit reached, almost at limit at 90%). Saves new contacts to the phone tagged VGC.
- **Sync.** Background timer (WorkManager) every 1h, 6h, 12h or 24h, can be paused. Opening the app always syncs. Android may delay background syncs on some phones.
- **History.** Days and People views. The phone keeps its own record (`HistoryLog`) because the database only sends counts per day. Each person has a WhatsApp chat button.
- **Increase my contact limit.** Three packs (+1,000, +3,000, +5,000) bought through Google Play Billing (`BillingManager.kt`). Prices come from Google Play. A purchase is checked by the Edge Function `verify-purchase` before the limit goes up, and only then consumed. The pop-up always shows the opposite of the app's light or dark mode.
- **Profile.** Sync settings, Delete My Contacts (removes only VGC contacts), FAQ, Purchase history (kept on the phone), Terms, Privacy, Delete my account, Log out.
- **Delete my account** (`DeleteAccountFragment.kt`). Calls `web_delete_account`: the member's data is deleted and the number goes on the deleted list. VGC contacts are removed from the phone, local records are cleared, and the member is logged out. No approval step.
- **Banned and Blocked pages** (`StopFragment.kt`, `Ban.kt`). Banned: the database answers BANNED, the phone remembers it, and the ViewGrow contacts it saved are removed. Blocked: password locked after too many wrong tries. The app only obeys what the database says.
- **Permissions.** A plain-words contacts disclosure (Agree / No thanks) shows before Android's Contacts box. Two permission steps: Contacts and Notifications. A turned-off permission is caught when the app opens, with a pop-up and a red box on Home.
- **Notifications.** Reminder after 3 days with no sync or with Contacts off; a notification that stays and opens the admin's WhatsApp chat to get the status; one alert at 80% of the limit; a weekly summary on Sunday at 6pm (nothing is sent in a week with no new contacts).
- **Chat button.** A floating button on Home, History and Profile opens the admin on WhatsApp.
- **Security.** The password is encrypted with the Android Keystore (`SecretBox.kt`). Internet only over HTTPS.

## Rules for whoever edits this repo
- Send the FULL updated zip (every file, paths from the repo root). Uploading a zip never deletes anything, so remove old files by hand.
- When something is replaced or dropped, delete the old file and its notes. Do not leave unused files.
- Keep this file and `docs/STATE_FROM_WEBSITE_REPO.md` in step with the website repo.
- Before Google Play: `docs/PLAY_STORE_CHECKLIST.md`.
